/**
 * \file Animal.cpp
 *
 * \author Jenn Proos
 */

#include "stdafx.h"
#include "Animal.h"


/**
 * Constructor.
 */
CAnimal::CAnimal()
{
}


/**
 * Destructor.
 */
CAnimal::~CAnimal()
{
}


/**
 * Display an animal.
 */
void CAnimal::DisplayAnimal()
{

}



/**
 * \returns number of legs 
 */
int CAnimal::NumLegs()
{
	return 0;
}